<?php

use App\Http\Controllers\Api\AssetController;
use App\Http\Controllers\Api\LoanController;
use App\Http\Controllers\Api\TicketController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| GABAH API Routes (Laravel 11)
|--------------------------------------------------------------------------
*/

Route::middleware('auth:sanctum')->group(function () {
    // Assets API
    Route::get('/assets', [AssetController::class, 'index'])->name('api.assets.index');
    Route::post('/assets', [AssetController::class, 'store'])->name('api.assets.store');
    Route::get('/assets/{asset}', [AssetController::class, 'show'])->name('api.assets.show');
    Route::get('/assets/{asset_number}/qr', [AssetController::class, 'qrCode'])->name('api.assets.show-qr');

    // Loans & Anti-Bentrok API
    Route::get('/loans', [LoanController::class, 'index'])->name('api.loans.index');
    Route::post('/loans', [LoanController::class, 'store'])->name('api.loans.store');
    Route::post('/loans/{loan}/approve', [LoanController::class, 'approve'])->name('api.loans.approve');
    Route::post('/loans/{loan}/handover', [LoanController::class, 'handover'])->name('api.loans.handover');
    Route::post('/loans/{loan}/return', [LoanController::class, 'returnAsset'])->name('api.loans.return');

    // Helpdesk Tickets & SLA API
    Route::get('/tickets', [TicketController::class, 'index'])->name('api.tickets.index');
    Route::post('/tickets', [TicketController::class, 'store'])->name('api.tickets.store');
    Route::get('/tickets/{ticket}', [TicketController::class, 'show'])->name('api.tickets.show');
});
