<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('assets', function (Blueprint $table) {
            $table->id();
            $table->string('asset_number', 50)->unique(); // ASTICK format: AST-IT-0001, AST-GA-0012, etc.
            $table->string('name', 200);
            $table->string('serial_number', 100)->nullable();
            $table->string('hostname', 100)->nullable(); // IT Specific
            $table->string('ip_address', 45)->nullable(); // IT Specific (IPv4 / IPv6)
            $table->string('category_type', 20); // IT, General, License (CategoryType enum)
            $table->foreignId('asset_category_id')->constrained('asset_categories')->cascadeOnUpdate()->restrictOnDelete();
            $table->string('status', 30)->default('available'); // available, in_use, maintenance, disposed
            $table->string('location', 150);
            $table->foreignId('assigned_to')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('vendor_id')->nullable()->constrained('vendors')->nullOnDelete();
            $table->foreignId('pic_id')->nullable()->constrained('users')->nullOnDelete();
            $table->date('purchase_date')->nullable();
            $table->date('warranty_until')->nullable();
            $table->decimal('price', 15, 2)->default(0);
            $table->jsonb('custom_attributes')->nullable(); // PostgreSQL JSONB for flexible hardware/GA specs
            $table->string('qr_code_url', 255)->nullable();
            $table->boolean('is_loanable')->default(false); // Bisa dipinjamkan
            $table->boolean('loan_blocked')->default(false); // Sedang di-lock / tidak bisa dipinjam saat ini
            $table->timestamps();

            $table->index(['category_type', 'status']);
            $table->index(['asset_number']);
            $table->index(['is_loanable', 'loan_blocked']);
            $table->index(['assigned_to']);
            $table->index(['warranty_until']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('assets');
    }
};
