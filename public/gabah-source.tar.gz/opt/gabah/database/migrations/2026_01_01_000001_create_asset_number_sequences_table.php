<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('asset_number_sequences', function (Blueprint $table) {
            $table->id();
            $table->string('category_code', 20)->index();
            $table->unsignedSmallInteger('year')->index();
            $table->unsignedInteger('last_number')->default(0);
            $table->timestamps();

            // Unique constraint to strictly isolate sequences per category and year
            $table->unique(['category_code', 'year'], 'uniq_asset_num_seq_cat_year');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('asset_number_sequences');
    }
};
