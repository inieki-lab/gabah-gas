<?php

namespace Database\Seeders;

use App\Enums\AssetStatus;
use App\Enums\CategoryType;
use App\Models\Asset;
use App\Models\AssetCategory;
use App\Models\User;
use App\Models\Vendor;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. Roles & Permissions setup
        $roles = [
            'Super Admin' => 'Akses penuh seluruh modul sistem',
            'IT Manager' => 'Persetujuan tiket IT, manajemen aset IT & lisensi',
            'IT Support' => 'Penanganan operasional helpdesk & aset IT',
            'GA' => 'Persetujuan peminjaman & aset umum kantor',
            'GA Staff' => 'Operasional logistik & serah terima barang',
            'Auditor' => 'Audit log, laporan aset, dan kepatuhan',
            'User' => 'Karyawan umum (peminjaman & tiket kendala)',
        ];

        foreach ($roles as $name => $label) {
            Role::firstOrCreate(['name' => $name, 'guard_name' => 'web'], ['label' => $label]);
        }

        // 2. Default Users
        $superAdmin = User::firstOrCreate(
            ['email' => 'admin@gabah.internal'],
            [
                'name' => 'Budi Santoso',
                'password' => Hash::make('password123'),
                'is_active' => true,
            ]
        );
        $superAdmin->assignRole('Super Admin');

        $itManager = User::firstOrCreate(
            ['email' => 'it.manager@gabah.internal'],
            [
                'name' => 'Rian Hidayat',
                'password' => Hash::make('password123'),
                'is_active' => true,
            ]
        );
        $itManager->assignRole('IT Manager');

        $gaStaff = User::firstOrCreate(
            ['email' => 'ga.staff@gabah.internal'],
            [
                'name' => 'Dewi Lestari',
                'password' => Hash::make('password123'),
                'is_active' => true,
            ]
        );
        $gaStaff->assignRole('GA Staff');

        // 3. Asset Categories (Specifying standard IT hardware codes & General categories)
        $categories = [
            // Standard IT Hardware Categories (Specification Section 4)
            ['code' => 'HLT', 'name' => 'Laptop', 'category_type' => CategoryType::IT],
            ['code' => 'HPC', 'name' => 'Desktop PC', 'category_type' => CategoryType::IT],
            ['code' => 'HMN', 'name' => 'Monitor', 'category_type' => CategoryType::IT],
            ['code' => 'HSV', 'name' => 'Server', 'category_type' => CategoryType::IT],
            ['code' => 'HNS', 'name' => 'NAS / Storage', 'category_type' => CategoryType::IT],
            ['code' => 'HSW', 'name' => 'Switch', 'category_type' => CategoryType::IT],
            ['code' => 'HRT', 'name' => 'Router', 'category_type' => CategoryType::IT],
            ['code' => 'HFW', 'name' => 'Firewall', 'category_type' => CategoryType::IT],
            ['code' => 'HAP', 'name' => 'Access Point', 'category_type' => CategoryType::IT],
            ['code' => 'HPR', 'name' => 'Printer', 'category_type' => CategoryType::IT],
            ['code' => 'HSC', 'name' => 'Scanner', 'category_type' => CategoryType::IT],
            ['code' => 'HUP', 'name' => 'UPS', 'category_type' => CategoryType::IT],
            ['code' => 'HKB', 'name' => 'Keyboard', 'category_type' => CategoryType::IT],
            ['code' => 'HMS', 'name' => 'Mouse', 'category_type' => CategoryType::IT],
            ['code' => 'HWC', 'name' => 'Webcam', 'category_type' => CategoryType::IT],
            ['code' => 'HHS', 'name' => 'Headset', 'category_type' => CategoryType::IT],
            ['code' => 'HDK', 'name' => 'Docking Station', 'category_type' => CategoryType::IT],
            ['code' => 'HPJ', 'name' => 'Projector', 'category_type' => CategoryType::IT],
            ['code' => 'HPH', 'name' => 'Smartphone', 'category_type' => CategoryType::IT],
            ['code' => 'HTB', 'name' => 'Tablet', 'category_type' => CategoryType::IT],

            // General Affairs & Facility Categories
            ['code' => 'GVEH', 'name' => 'Kendaraan Operasional', 'category_type' => CategoryType::GENERAL],
            ['code' => 'GFUR', 'name' => 'Furniture & Meja Kerja', 'category_type' => CategoryType::GENERAL],
            ['code' => 'GAVM', 'name' => 'AV & Sound System', 'category_type' => CategoryType::GENERAL],

            // Licenses
            ['code' => 'LSAS', 'name' => 'Cloud & SaaS Subscription', 'category_type' => CategoryType::LICENSE],
            ['code' => 'LOSY', 'name' => 'Operating System & Productivity', 'category_type' => CategoryType::LICENSE],

            // Legacy backward-compatible codes
            ['code' => 'IT-LAP', 'name' => 'Laptop & Workstation (Legacy)', 'category_type' => CategoryType::IT],
            ['code' => 'IT-SRV', 'name' => 'Server & Datacenter (Legacy)', 'category_type' => CategoryType::IT],
            ['code' => 'IT-NET', 'name' => 'Network & Firewall (Legacy)', 'category_type' => CategoryType::IT],
            ['code' => 'GA-VEH', 'name' => 'Kendaraan Operasional (Legacy)', 'category_type' => CategoryType::GENERAL],
            ['code' => 'GA-FUR', 'name' => 'Furniture & Meja Kerja (Legacy)', 'category_type' => CategoryType::GENERAL],
            ['code' => 'GA-PRJ', 'name' => 'Proyektor & AV Meeting Room (Legacy)', 'category_type' => CategoryType::GENERAL],
            ['code' => 'LIC-CLD', 'name' => 'Cloud & SaaS Subscription (Legacy)', 'category_type' => CategoryType::LICENSE],
            ['code' => 'LIC-OS', 'name' => 'Operating System & Productivity (Legacy)', 'category_type' => CategoryType::LICENSE],
        ];

        foreach ($categories as $cat) {
            AssetCategory::firstOrCreate(['code' => $cat['code']], $cat);
        }

        // 4. Vendors
        $vendor1 = Vendor::firstOrCreate(
            ['name' => 'PT Mitra Solusi Informatika'],
            [
                'type' => 'IT Hardware & Enterprise',
                'contact_person' => 'Hendrawan',
                'phone' => '+62 21 555-0199',
                'email' => 'sales@mitrasolusi.co.id',
                'address' => 'Jl. TB Simatupang No. 18, Jakarta Selatan',
            ]
        );

        // 5. Sample Assets
        $laptopCat = AssetCategory::where('code', 'HLT')->first() ?: AssetCategory::where('code', 'IT-LAP')->first();
        if ($laptopCat) {
            Asset::firstOrCreate(
                ['asset_number' => 'IT-HLT-2026-0001'],
                [
                    'name' => 'ThinkPad T14s Gen 4 (Core i7 / 32GB RAM / 1TB SSD)',
                    'serial_number' => 'PF49B89X',
                    'hostname' => 'HO-IT-NB-042',
                    'ip_address' => '192.168.10.45',
                    'category_type' => CategoryType::IT->value,
                    'asset_category_id' => $laptopCat->id,
                    'status' => AssetStatus::AVAILABLE->value,
                    'location' => 'HQ - Lantai 4 IT Asset Room',
                    'vendor_id' => $vendor1->id,
                    'purchase_date' => '2026-01-15',
                    'warranty_until' => '2029-01-15',
                    'price' => 24500000,
                    'custom_attributes' => [
                        'cpu' => 'Intel Core i7-1365U vPro',
                        'ram' => '32GB LPDDR5x',
                        'storage' => '1TB NVMe PCIe 4.0',
                        'os' => 'Windows 11 Pro Enterprise',
                    ],
                    'is_loanable' => true,
                    'loan_blocked' => false,
                ]
            );
        }

        $projCat = AssetCategory::where('code', 'HPJ')->first() ?: AssetCategory::where('code', 'GA-PRJ')->first();
        if ($projCat) {
            Asset::firstOrCreate(
                ['asset_number' => 'IT-HPJ-2026-0001'],
                [
                    'name' => 'Epson EB-2250U 5000 Lumens Full HD Projector',
                    'serial_number' => 'EP2250-8812',
                    'hostname' => null,
                    'ip_address' => null,
                    'category_type' => CategoryType::IT->value,
                    'asset_category_id' => $projCat->id,
                    'status' => AssetStatus::AVAILABLE->value,
                    'location' => 'HQ - Ruang Logistik GA',
                    'purchase_date' => '2026-02-10',
                    'warranty_until' => '2028-02-10',
                    'price' => 18900000,
                    'custom_attributes' => [
                        'lumens' => '5000 ANSI Lumens',
                        'resolution' => 'WUXGA 1920x1200',
                        'included_cables' => ['HDMI 10m', 'Power Cord', 'Remote'],
                    ],
                    'is_loanable' => true,
                    'loan_blocked' => false,
                ]
            );
        }
    }
}
