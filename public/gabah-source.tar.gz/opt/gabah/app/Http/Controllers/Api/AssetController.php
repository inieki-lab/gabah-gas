<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api;

use App\Enums\CategoryType;
use App\Http\Controllers\Controller;
use App\Http\Requests\Asset\StoreAssetRequest;
use App\Http\Requests\Asset\UpdateAssetRequest;
use App\Models\Asset;
use App\Services\AssetService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use SimpleSoftwareIO\QrCode\Facades\QrCode;

/**
 * Thin API Controller: Delegate all heavy business logic to AssetService
 */
class AssetController extends Controller
{
    public function __construct(
        protected AssetService $assetService
    ) {}

    public function index(Request $request): JsonResponse
    {
        $this->authorize('viewAny', Asset::class);

        $query = Asset::with(['category', 'assignedUser', 'vendor', 'pic']);

        if ($request->filled('category_type')) {
            $query->where('category_type', $request->query('category_type'));
        }

        if ($request->filled('status')) {
            $query->where('status', $request->query('status'));
        }

        if ($request->filled('search')) {
            $search = $request->query('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'ILIKE', "%{$search}%")
                  ->orWhere('asset_number', 'ILIKE', "%{$search}%")
                  ->orWhere('serial_number', 'ILIKE', "%{$search}%")
                  ->orWhere('hostname', 'ILIKE', "%{$search}%")
                  ->orWhere('ip_address', 'ILIKE', "%{$search}%");
            });
        }

        $assets = $query->paginate($request->integer('per_page', 15));

        return response()->json($assets);
    }

    public function store(StoreAssetRequest $request): JsonResponse
    {
        $category = \App\Models\AssetCategory::findOrFail($request->validated('asset_category_id'));
        $this->authorize('create', [Asset::class, $category->category_type]);

        $asset = $this->assetService->createAsset(
            $request->validated(),
            $request->user()
        );

        return response()->json([
            'message' => 'Aset berhasil didaftarkan.',
            'data' => $asset->load(['category', 'assignedUser', 'vendor']),
        ], 201);
    }

    public function show(Asset $asset): JsonResponse
    {
        $this->authorize('view', $asset);

        return response()->json([
            'data' => $asset->load(['category', 'assignedUser', 'vendor', 'pic', 'loans', 'tickets']),
        ]);
    }

    public function qrCode(string $assetNumber)
    {
        $asset = Asset::where('asset_number', $assetNumber)->firstOrFail();
        $this->authorize('view', $asset);

        $qrPayload = json_encode([
            'asset_number' => $asset->asset_number,
            'name' => $asset->name,
            'category_type' => $asset->category_type->value,
            'serial' => $asset->serial_number,
            'url' => url("/assets/{$asset->id}"),
        ]);

        return response(QrCode::format('png')->size(300)->generate($qrPayload))
            ->header('Content-Type', 'image/png');
    }
}
