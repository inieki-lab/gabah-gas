<?php

declare(strict_types=1);

namespace App\Http\Requests\Asset;

use App\Enums\CategoryType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreAssetRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:200'],
            'asset_category_id' => ['required', 'exists:asset_categories,id'],
            'serial_number' => ['nullable', 'string', 'max:100'],
            'hostname' => ['nullable', 'string', 'max:100'],
            'ip_address' => ['nullable', 'ip'],
            'location' => ['required', 'string', 'max:150'],
            'assigned_to' => ['nullable', 'exists:users,id'],
            'vendor_id' => ['nullable', 'exists:vendors,id'],
            'pic_id' => ['nullable', 'exists:users,id'],
            'purchase_date' => ['nullable', 'date'],
            'warranty_until' => ['nullable', 'date', 'after_or_equal:purchase_date'],
            'price' => ['nullable', 'numeric', 'min:0'],
            'custom_attributes' => ['nullable', 'array'],
            'is_loanable' => ['boolean'],
        ];
    }

    /**
     * Ensure client-supplied asset_number is never trusted.
     */
    public function validated($key = null, $default = null): mixed
    {
        $validated = parent::validated($key, $default);
        if (is_array($validated)) {
            unset($validated['asset_number']);
        }
        return $validated;
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Nama aset wajib diisi.',
            'asset_category_id.required' => 'Kategori aset wajib dipilih.',
            'asset_category_id.exists' => 'Kategori aset tidak ditemukan dalam sistem.',
            'ip_address.ip' => 'Format IP Address tidak valid (IPv4/IPv6).',
            'location.required' => 'Lokasi penempatan aset wajib diisi.',
            'warranty_until.after_or_equal' => 'Tanggal akhir garansi tidak boleh sebelum tanggal pembelian.',
        ];
    }
}
