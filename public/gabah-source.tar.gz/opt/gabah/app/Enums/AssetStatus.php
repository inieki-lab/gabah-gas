<?php

declare(strict_types=1);

namespace App\Enums;

enum AssetStatus: string
{
    case AVAILABLE = 'available';
    case IN_USE = 'in_use';
    case MAINTENANCE = 'maintenance';
    case DISPOSED = 'disposed';

    public function label(): string
    {
        return match ($this) {
            self::AVAILABLE => 'Tersedia',
            self::IN_USE => 'Sedang Digunakan',
            self::MAINTENANCE => 'Perbaikan / Maintenance',
            self::DISPOSED => 'Dihapusbukukan / Afkir',
        };
    }
}
