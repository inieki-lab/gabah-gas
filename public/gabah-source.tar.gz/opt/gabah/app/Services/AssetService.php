<?php

declare(strict_types=1);

namespace App\Services;

use App\Enums\AssetStatus;
use App\Enums\CategoryType;
use App\Models\Asset;
use App\Models\AssetCategory;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AssetService
{
    public function __construct(
        protected AuditLogService $auditLogService,
        protected AssetNumberingService $assetNumberingService
    ) {}

    /**
     * Generate Nomor Aset menggunakan AssetNumberingService:
     * Format: IT-{CATEGORY_CODE}-{YEAR}-{SEQUENCE}
     * Contoh: IT-HLT-2026-0001
     */
    public function generateAssetNumber(AssetCategory|CategoryType|string $category): string
    {
        if ($category instanceof AssetCategory) {
            return $this->assetNumberingService->generate($category);
        }

        if ($category instanceof CategoryType) {
            $code = match ($category) {
                CategoryType::IT => 'IT',
                CategoryType::GENERAL => 'GA',
                CategoryType::LICENSE => 'LIC',
            };
            return $this->assetNumberingService->generate($code);
        }

        return $this->assetNumberingService->generate((string) $category);
    }

    /**
     * Mendaftarkan Aset Baru dalam Database Transaction
     */
    public function createAsset(array $data, ?User $actor = null): Asset
    {
        return DB::transaction(function () use ($data, $actor) {
            $category = AssetCategory::findOrFail($data['asset_category_id']);
            $categoryType = $category->category_type;

            // Asset code is strictly server-generated. Client input for asset_number is ignored.
            $assetNumber = $this->assetNumberingService->generate($category);

            // Double check safety constraint (final safeguard)
            if (Asset::where('asset_number', $assetNumber)->exists()) {
                throw ValidationException::withMessages([
                    'asset_number' => "Nomor aset {$assetNumber} sudah terdaftar dalam sistem.",
                ]);
            }

            // QR Code URL format
            $qrUrl = route('api.assets.show-qr', ['asset_number' => $assetNumber], false);

            $asset = Asset::create([
                'asset_number' => $assetNumber,
                'name' => $data['name'],
                'serial_number' => $data['serial_number'] ?? null,
                'hostname' => $data['hostname'] ?? null,
                'ip_address' => $data['ip_address'] ?? null,
                'category_type' => $categoryType->value,
                'asset_category_id' => $category->id,
                'status' => $data['status'] ?? AssetStatus::AVAILABLE->value,
                'location' => $data['location'],
                'assigned_to' => $data['assigned_to'] ?? null,
                'vendor_id' => $data['vendor_id'] ?? null,
                'pic_id' => $data['pic_id'] ?? null,
                'purchase_date' => $data['purchase_date'] ?? null,
                'warranty_until' => $data['warranty_until'] ?? null,
                'price' => $data['price'] ?? 0,
                'custom_attributes' => $data['custom_attributes'] ?? [],
                'qr_code_url' => $qrUrl,
                'is_loanable' => $data['is_loanable'] ?? false,
                'loan_blocked' => false,
            ]);

            $this->auditLogService->log(
                $actor?->id,
                'ASSET_CREATE',
                Asset::class,
                $asset->id,
                null,
                $asset->toArray()
            );

            return $asset;
        });
    }

    /**
     * Memperbarui Data Aset
     * Perhatian: Nomor Aset (asset_number) bersifat IMMUTABLE dan tidak boleh diubah pada normal edit.
     */
    public function updateAsset(Asset $asset, array $data, ?User $actor = null): Asset
    {
        return DB::transaction(function () use ($asset, $data, $actor) {
            $oldValues = $asset->toArray();

            // Strict rule: asset_number is immutable upon creation
            unset($data['asset_number']);

            $asset->update($data);

            $this->auditLogService->log(
                $actor?->id,
                'ASSET_UPDATE',
                Asset::class,
                $asset->id,
                $oldValues,
                $asset->fresh()->toArray()
            );

            return $asset;
        });
    }
}
