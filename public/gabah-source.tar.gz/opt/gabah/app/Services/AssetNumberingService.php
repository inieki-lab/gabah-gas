<?php

namespace App\Services;

use App\Models\AssetCategory;
use App\Models\AssetNumberSequence;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class AssetNumberingService
{
    public const PREFIX = 'IT';
    public const MIN_PADDING = 4;

    /**
     * Atomically generate a unique asset number for a given category and year.
     * Format: IT-{CATEGORY_CODE}-{YEAR}-{SEQUENCE}
     *
     * @param  AssetCategory|string  $category
     * @param  int|null  $year
     * @return string
     *
     * @throws InvalidArgumentException
     */
    public function generate(AssetCategory|string $category, ?int $year = null): string
    {
        $categoryCode = $this->resolveCategoryCode($category);
        $targetYear = $year ?? (int) date('Y');

        return DB::transaction(function () use ($categoryCode, $targetYear) {
            // Attempt to acquire lock on the existing sequence record
            $sequence = AssetNumberSequence::where('category_code', $categoryCode)
                ->where('year', $targetYear)
                ->lockForUpdate()
                ->first();

            if (! $sequence) {
                // Safely create sequence entry if not exists
                // Use firstOrCreate to prevent race conditions during first creation
                $sequence = AssetNumberSequence::firstOrCreate(
                    [
                        'category_code' => $categoryCode,
                        'year' => $targetYear,
                    ],
                    [
                        'last_number' => 0,
                    ]
                );

                // Acquire row-level lock on the row
                $sequence = AssetNumberSequence::where('id', $sequence->id)
                    ->lockForUpdate()
                    ->first();
            }

            // Increment atomic sequence
            $sequence->last_number += 1;
            $sequence->save();

            return $this->formatAssetNumber($categoryCode, $targetYear, $sequence->last_number);
        });
    }

    /**
     * Preview next asset number without incrementing or saving sequence.
     * Useful for UI hints and read-only displays.
     *
     * @param  AssetCategory|string  $category
     * @param  int|null  $year
     * @return string
     */
    public function previewNext(AssetCategory|string $category, ?int $year = null): string
    {
        $categoryCode = $this->resolveCategoryCode($category);
        $targetYear = $year ?? (int) date('Y');

        $sequence = AssetNumberSequence::where('category_code', $categoryCode)
            ->where('year', $targetYear)
            ->first();

        $nextNumber = ($sequence?->last_number ?? 0) + 1;

        return $this->formatAssetNumber($categoryCode, $targetYear, $nextNumber);
    }

    /**
     * Get the last recorded sequence number for given category code and year.
     */
    public function getLastSequence(string $categoryCode, int $year): int
    {
        $sequence = AssetNumberSequence::where('category_code', strtoupper(trim($categoryCode)))
            ->where('year', $year)
            ->first();

        return $sequence?->last_number ?? 0;
    }

    /**
     * Format into standard specification: IT-{CATEGORY_CODE}-{YEAR}-{SEQUENCE}
     */
    public function formatAssetNumber(string $categoryCode, int $year, int $sequenceNumber): string
    {
        $padding = max(self::MIN_PADDING, strlen((string) $sequenceNumber));
        $formattedSequence = str_pad((string) $sequenceNumber, $padding, '0', STR_PAD_LEFT);

        return sprintf('%s-%s-%d-%s', self::PREFIX, $categoryCode, $year, $formattedSequence);
    }

    /**
     * Validate and resolve the category code string.
     *
     * @throws InvalidArgumentException
     */
    public function resolveCategoryCode(AssetCategory|string $category): string
    {
        if ($category instanceof AssetCategory) {
            $code = $category->code;
            $categoryName = $category->name;
        } else {
            $code = $category;
            $categoryName = $category;
        }

        $code = strtoupper(trim((string) $code));

        if (empty($code)) {
            throw new InvalidArgumentException(
                sprintf('Asset category code is not configured for category [%s].', $categoryName ?: 'Unknown')
            );
        }

        return $code;
    }
}
