<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Asset;
use App\Models\AuditLog;
use Illuminate\Support\Facades\Log;

class CheckAssetExpirations extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'assets:check-expirations {--days=30 : Threshold days for expiration warning}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pemeriksaan berkala masa berlaku garansi hardware dan perpanjangan lisensi software enterprise';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $days = (int) $this->option('days');
        $this->info("Scanning assets & software licenses expiring within {$days} days...");

        $now = now();
        $targetDate = now()->addDays($days);

        // Hardware warranties expiring soon
        $expiringHardware = Asset::whereIn('category_type', ['IT', 'General'])
            ->whereNotNull('warranty_expiry')
            ->whereBetween('warranty_expiry', [$now, $targetDate])
            ->get();

        // Software licenses / subscriptions expiring soon
        $expiringLicenses = Asset::where('category_type', 'License')
            ->whereNotNull('warranty_expiry')
            ->whereBetween('warranty_expiry', [$now, $targetDate])
            ->get();

        $this->line("Results:");
        $this->line("- Hardware Warranties Expiring: {$expiringHardware->count()} unit(s)");
        $this->line("- Software Licenses Expiring: {$expiringLicenses->count()} contract(s)");

        foreach ($expiringHardware as $asset) {
            $daysLeft = $now->diffInDays($asset->warranty_expiry);
            $this->warn("  * [WARRANTY ALERT] {$asset->astick_internal_number} - {$asset->name} ({$daysLeft} days remaining)");
        }

        foreach ($expiringLicenses as $license) {
            $daysLeft = $now->diffInDays($license->warranty_expiry);
            $this->warn("  * [LICENSE RENEWAL] {$license->astick_internal_number} - {$license->name} ({$daysLeft} days remaining - requires procurement review)");
        }

        if ($expiringHardware->isNotEmpty() || $expiringLicenses->isNotEmpty()) {
            AuditLog::create([
                'user_id' => null,
                'user_name' => 'SYSTEM CRON (LIFECYCLE AUDITOR)',
                'user_role' => 'system',
                'action' => 'ASSET_EXPIRATIONS_AUDIT_RAN',
                'target_type' => 'AssetCollection',
                'target_id' => null,
                'ip_address' => '127.0.0.1',
                'details' => [
                    'threshold_days' => $days,
                    'hardware_count' => $expiringHardware->count(),
                    'licenses_count' => $expiringLicenses->count(),
                    'audited_at' => $now->toIso8601String(),
                ],
            ]);
        }

        $this->info("Expiration check completed successfully.");
        return Command::SUCCESS;
    }
}
