<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Ticket;
use App\Models\AuditLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CheckTicketSla extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'tickets:check-sla {--escalate : Auto-escalate priority on breach}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Pantau batas SLA Helpdesk dan eskalasikan tiket gangguan yang melewati target resolusi';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Monitoring Helpdesk SLA compliance...');

        $now = now();
        $shouldEscalate = $this->option('escalate');

        // Check tickets breaching resolution SLA
        $breachedTickets = Ticket::whereIn('status', ['open', 'in_progress', 'pending_vendor'])
            ->where('sla_due_at', '<', $now)
            ->where('is_over_sla', false)
            ->with(['reporter', 'assignedAgent'])
            ->get();

        if ($breachedTickets->isEmpty()) {
            $this->info('All active tickets are within SLA boundaries.');
            return Command::SUCCESS;
        }

        $this->warn("Detected {$breachedTickets->count()} ticket(s) breaching SLA targets. Processing...");

        foreach ($breachedTickets as $ticket) {
            $overdueHours = round($now->diffInMinutes($ticket->sla_due_at) / 60, 1);
            $this->line("- [SLA BREACH] Ticket: {$ticket->ticket_code} | Title: {$ticket->title} | Priority: {$ticket->priority} | Breached by {$overdueHours}h");

            DB::transaction(function () use ($ticket, $overdueHours, $shouldEscalate) {
                $updates = ['is_over_sla' => true];

                // Auto-escalation logic: bump priority if requested
                if ($shouldEscalate && $ticket->priority !== 'urgent') {
                    $nextPriority = match ($ticket->priority) {
                        'low' => 'medium',
                        'medium' => 'high',
                        'high' => 'urgent',
                        default => 'urgent',
                    };
                    $updates['priority'] = $nextPriority;
                    $this->comment("  -> Auto-escalating priority from {$ticket->priority} to {$nextPriority}");
                }

                $ticket->update($updates);

                AuditLog::create([
                    'user_id' => null,
                    'user_name' => 'SYSTEM CRON (SLA GUARDIAN)',
                    'user_role' => 'system',
                    'action' => 'TICKET_SLA_BREACHED',
                    'target_type' => 'Ticket',
                    'target_id' => $ticket->id,
                    'ip_address' => '127.0.0.1',
                    'details' => [
                        'ticket_code' => $ticket->ticket_code,
                        'priority' => $ticket->priority,
                        'breached_hours' => $overdueHours,
                        'assigned_agent' => $ticket->assignedAgent?->name ?? 'Unassigned',
                        'target_sla_due' => $ticket->sla_due_at->toIso8601String(),
                    ],
                ]);

                Log::channel('daily')->warning("GABAH SLA Violation: Ticket {$ticket->ticket_code} exceeded target by {$overdueHours} hours.");
            });
        }

        $this->info("Successfully audited and flagged {$breachedTickets->count()} ticket(s).");
        return Command::SUCCESS;
    }
}
