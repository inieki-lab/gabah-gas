<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\LoanReservation;
use App\Models\AuditLog;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class CheckOverdueLoans extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'loans:check-overdue {--dry-run : Run without updating records}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Periksa pinjaman aset yang melewati batas waktu pengembalian (Overdue) dan catat audit log pelanggaran';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $this->info('Starting overdue loan inspection...');

        $now = now();
        $isDryRun = $this->option('dry-run');

        $overdueLoans = LoanReservation::where('status', 'active')
            ->where('end_date', '<', $now)
            ->with(['asset', 'borrower'])
            ->get();

        if ($overdueLoans->isEmpty()) {
            $this->info('No overdue loans detected.');
            return Command::SUCCESS;
        }

        $this->warn("Found {$overdueLoans->count()} overdue loan(s). Processing...");

        foreach ($overdueLoans as $loan) {
            $daysOverdue = $now->diffInDays($loan->end_date);
            $this->line("- [OVERDUE] Loan: {$loan->loan_code} | Asset: {$loan->asset->astick_internal_number} | Borrower: {$loan->borrower->name} ({$daysOverdue} days late)");

            if (!$isDryRun) {
                DB::transaction(function () use ($loan, $daysOverdue, $now) {
                    $loan->update([
                        'status' => 'overdue',
                        'overdue_flagged_at' => $now,
                    ]);

                    AuditLog::create([
                        'user_id' => null,
                        'user_name' => 'SYSTEM CRON (GABAH DAEMON)',
                        'user_role' => 'system',
                        'action' => 'LOAN_OVERDUE_FLAGGED',
                        'target_type' => 'LoanReservation',
                        'target_id' => $loan->id,
                        'ip_address' => '127.0.0.1',
                        'details' => [
                            'loan_code' => $loan->loan_code,
                            'borrower_id' => $loan->borrower_id,
                            'borrower_name' => $loan->borrower->name,
                            'asset_code' => $loan->asset->astick_internal_number,
                            'days_overdue' => $daysOverdue,
                            'scheduled_end_date' => $loan->end_date->toIso8601String(),
                        ],
                    ]);

                    Log::warning("GABAH Alert: Loan {$loan->loan_code} is overdue by {$daysOverdue} days. Borrower {$loan->borrower->name} flagged.");
                });
            }
        }

        $this->info("Successfully processed {$overdueLoans->count()} overdue loan(s).");
        return Command::SUCCESS;
    }
}
