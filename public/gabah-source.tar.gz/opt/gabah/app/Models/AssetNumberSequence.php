<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AssetNumberSequence extends Model
{
    use HasFactory;

    protected $table = 'asset_number_sequences';

    protected $fillable = [
        'category_code',
        'year',
        'last_number',
    ];

    protected $casts = [
        'year' => 'integer',
        'last_number' => 'integer',
    ];
}
