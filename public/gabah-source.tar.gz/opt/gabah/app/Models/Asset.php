<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\AssetStatus;
use App\Enums\CategoryType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Asset extends Model
{
    use HasFactory;

    protected $fillable = [
        'asset_number',
        'name',
        'serial_number',
        'hostname',
        'ip_address',
        'category_type',
        'asset_category_id',
        'status',
        'location',
        'assigned_to',
        'vendor_id',
        'pic_id',
        'purchase_date',
        'warranty_until',
        'price',
        'custom_attributes',
        'qr_code_url',
        'is_loanable',
        'loan_blocked',
    ];

    protected $casts = [
        'category_type' => CategoryType::class,
        'status' => AssetStatus::class,
        'purchase_date' => 'date',
        'warranty_until' => 'date',
        'price' => 'decimal:2',
        'custom_attributes' => 'array',
        'is_loanable' => 'boolean',
        'loan_blocked' => 'boolean',
    ];

    public function category(): BelongsTo
    {
        return $this->belongsTo(AssetCategory::class, 'asset_category_id');
    }

    public function assignedUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function pic(): BelongsTo
    {
        return $this->belongsTo(User::class, 'pic_id');
    }

    public function vendor(): BelongsTo
    {
        return $this->belongsTo(Vendor::class, 'vendor_id');
    }

    public function loans(): HasMany
    {
        return $this->hasMany(Loan::class, 'asset_id');
    }

    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class, 'asset_id');
    }
}
