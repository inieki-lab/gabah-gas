<?php

declare(strict_types=1);

namespace App\Policies;

use App\Enums\CategoryType;
use App\Models\Asset;
use App\Models\User;

class AssetPolicy
{
    /**
     * Super Admin bypasses all checks
     */
    public function before(User $user, string $ability): ?bool
    {
        if ($user->hasRole('Super Admin')) {
            return true;
        }

        return null;
    }

    public function viewAny(User $user): bool
    {
        return $user->hasAnyRole(['Super Admin', 'IT Manager', 'IT Support', 'GA', 'GA Staff', 'Auditor', 'User']);
    }

    public function view(User $user, Asset $asset): bool
    {
        return true;
    }

    /**
     * Granular per category_type RBAC
     */
    public function create(User $user, CategoryType $categoryType): bool
    {
        return match ($categoryType) {
            CategoryType::IT, CategoryType::LICENSE => $user->hasAnyRole(['IT Manager', 'IT Support']),
            CategoryType::GENERAL => $user->hasAnyRole(['GA', 'GA Staff']),
        };
    }

    public function update(User $user, Asset $asset): bool
    {
        return match ($asset->category_type) {
            CategoryType::IT, CategoryType::LICENSE => $user->hasAnyRole(['IT Manager', 'IT Support']),
            CategoryType::GENERAL => $user->hasAnyRole(['GA', 'GA Staff']),
        };
    }

    public function delete(User $user, Asset $asset): bool
    {
        return match ($asset->category_type) {
            CategoryType::IT, CategoryType::LICENSE => $user->hasRole('IT Manager'),
            CategoryType::GENERAL => $user->hasRole('GA'),
        };
    }
}
